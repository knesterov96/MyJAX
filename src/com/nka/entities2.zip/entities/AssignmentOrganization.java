package com.nka.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.json.JSONArray;
import org.json.JSONObject;

@Entity
@Table (name = "assignment")
public class AssignmentOrganization {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column (name = "subject")
    private String subject;
    
    @Column (name = "text")
    private String text;
    
    @Temporal (TemporalType.DATE)
    @Column (name = "end_date")
    private Date endDate;
    
    @Column (name = "control")
    private Boolean control;
    
    @Column (name = "execution")
    private Boolean execution;
    
    @ManyToOne (fetch = FetchType.EAGER)
    @JoinColumn (name = "head_organization")
    private HeadOrganization headOrganization;
    
    @ManyToMany (cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    @JoinTable(
            name = "assignment_subdivision", 
            joinColumns = { @JoinColumn(name = "assignment") }, 
            inverseJoinColumns = { @JoinColumn(name = "head_subdivision") }
    )
    private Set<HeadSubdivision> headSubdivisions = new HashSet<HeadSubdivision>();
    
    @ManyToMany (cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    @JoinTable(
            name = "assignment_employee", 
            joinColumns = { @JoinColumn(name = "assignment") }, 
            inverseJoinColumns = { @JoinColumn(name = "employee") }
    )
    private Set<Employee> employees = new HashSet<Employee>();
    
    public AssignmentOrganization () {}
    
    public AssignmentOrganization (
        String subject,
        String text,
        Date endDate,
        Boolean control,
        Boolean execution,
        HeadOrganization headOrganization,
        Set<HeadSubdivision> headSubdivisions,
        Set<Employee> employees
    ) {
      this.subject = subject;
      this.text = text;
      this.endDate = endDate;
      this.control = control;
      this.execution = execution;
      this.headOrganization = headOrganization;
      this.headSubdivisions = headSubdivisions;
      this.employees = employees;
    }
    
    public int getId () {
        return id;
      }
      
      public void setId (int id) {
        this.id = id;
      }
      
      public String getSubject() {
        return subject;
      }
      
      public void setSubject (String subject) {
        this.subject = subject;
      }
      
      public String getText () {
        return text;
      }
      
      public void setText (String text) {
        this.text = text;
      }
      
      public Date getEndDate () {
        return endDate;
      }
      
      public void setEndDate (Date endDate) {
        this.endDate = endDate;
      }
      
      public boolean getControl () {
        return control;
      }
      
      public void setControl (boolean control) {
        this.control = control;
      }
      
      public boolean getExecution () {
        return execution;
      }
      
      public void setExecution (boolean execution) {
        this.execution = execution;
      }
      
      public HeadOrganization getHeadOrganization () {
        return headOrganization;
      }
      
      public void setHeadOrganization (HeadOrganization headOrganization) {
        this.headOrganization = headOrganization;
      }
      
      public Set<HeadSubdivision> getHeadSubdivision () {
        return headSubdivisions;
      }
      
      public void setHeadSubdivision (Set<HeadSubdivision> headSubdivisions) {
        this.headSubdivisions = headSubdivisions;
      }
      
      public Set<Employee> getEmployee () {
        return employees;
      }
      
      public void setEmployee (Set<Employee> employees) {
        this.employees = employees;
      }
      
      @Override
      public String toString() {
        return "\r\nОбъект поручения: \"" + subject + "\"" +
               "\r\nТекст поручения: \"" + text + "\"" +
               "\r\n";
      }
      
      public JSONObject toJSONObject() {
        JSONObject res = new JSONObject();
        res.put("subject", subject);
        res.put("text", text);
        res.put("endDate", endDate);
        res.put("control", control);
        res.put("execution", execution);
        
        res.put("headOrganization", headOrganization.toJSONObject());
        
        JSONArray headSubdivsions = new JSONArray();
        this.headSubdivisions.forEach(hs -> {
          headSubdivsions.put(hs.toJSONObject());
        });
        
        res.put("headSubdivisions", headSubdivsions);
        
        JSONArray employees = new JSONArray();
        if(this.employees != null) {
          this.employees.forEach(e -> {
            employees.put(e.toJSONObject());
          });
        }
        res.put("employees", employees);
        
        return res;
      }
}