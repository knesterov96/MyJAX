package com.nka;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.json.JSONObject;

@Entity
@Table (name = "organization")
public class Organization {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column (
             name = "name",
             length = 200,
             nullable = false
    )
    private String name;
    
    @Column (
             name = "physical",
             length = 200,
             nullable = false
    )
    private String physical;
    
    @Column (
             name = "legal",
             length = 200,
             nullable = false
    )
    private String legal;
    
    public Organization () { }
    
    public Organization (
        String name,
        String physical,
        String legal
    ) {
      this.name = name;
      this.physical = physical;
      this.legal = legal;
    }
    
    public int getId () {
      return id;
    }
    
    public void setId (int id) {
      this.id = id;
    }
    
    public String getName () {
      return name;
    }
    
    public void setName (String name) {
      this.name = name;
    }
    
    public String getPhysical () {
      return physical;
    }
    
    public void setPhysical (String physical) {
      this.physical = physical;
    }
    
    public String getLegal () {
      return legal;
    }
    
    public void setLegal (String legal) {
      this.legal = legal;
    }
    
    @Override
    public String toString() {
      return "\r\n Название: \"" + name + "\"" +
         "\r\n Физический адрес: \"" + physical + "\"" +
         "\r\n Юридический адрес:\"" + legal + "\"" +
         "\r\n";
    }
    
    public JSONObject toJSONObject() {
      JSONObject res = new JSONObject();
      res.put("name", name);
      res.put("physical", physical);
      res.put("legal", legal);
      return res;
    }
}