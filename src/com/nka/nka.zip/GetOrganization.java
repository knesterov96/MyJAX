package com.nka;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/get_org")
public class GetOrganization {
  @GET
  @Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
  public Response home() {
    OrganizationManager om = new OrganizationManager();
    
    return Response
      .status(Response.Status.OK)
      .entity(om.getJSONArrayOrganization().toString(1))
      .type(MediaType.APPLICATION_JSON + ";charset=utf-8")
      .build();
  }
}