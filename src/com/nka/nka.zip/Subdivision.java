package com.nka;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.json.JSONObject;

@Entity
@Table (name = "subdivision")
public class Subdivision {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column (name = "name")
    private String name;
    
    @Column (name = "contact")
    private String contact;
    
    public Subdivision () { }
    
    public Subdivision (
        String name,
        String contact
    ) {
      this.name = name;
      this.contact = contact;
    }
    
    public int getId () {
      return id;
    }
    
    public void setId (int id) {
      this.id = id;
    }
    
    public String getName () {
      return name;
    }
    
    public void setName (String name) {
      this.name = name;
    }
    
    public String getContact () {
      return contact;
    }
    
    public void setContact (String contact) {
      this.contact = contact;
    }
    
    @Override
    public String toString() {
      return "\r\n Наименование подразделения: \"" + name + "\"" +
             "\r\n Контактные данные: \"" + contact + "\"" +
             "\r\n";
    }
    
    public JSONObject toJSONObject() {
      JSONObject res = new JSONObject();
      res.put("name", name);
      res.put("contact", contact);
      return res;
    }
}